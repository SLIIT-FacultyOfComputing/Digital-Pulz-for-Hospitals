<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <title></title>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.css'); ?>" media="all"/>

        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyRC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyDC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyBC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyUC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>validation.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Bootstrap/js/'; ?>bootstrap.js"></script>

    </head>

    <body onload="getCategoryListDC()">
        <div id="wrapper">
            <div id="header-wrapper">
                <?php $this->load->view('layout/Header');?>

                <div id="page">
                    <div id="content">
                        <div class="post">
                       <?php
        //==========================================
        $dusr = new Frequency_Controller();
        $details = $dusr->getFreqFromDb();
        //echo $frqPcs[1];
        //==========================================
        ?>
        <div>
            <p><h1>Drug Frequency Manager</h1></p>
        </div>
        <form action='http://localhost/eHealth_proj/index.php/Frequency_Controller/updateFreq' method='post'>

            <table class="table1">
                <thead>
                    <tr>
                        <th>Frequency Id</th>
                        <th>Drug Frequency</th>
                        <th>Update</th>
                    </tr>


                </thead>
                <?php
                $s=0;
                foreach ($details as $value) {
                    $frqPcs = explode(":", $details[$s]);
                ?>
                    <tr>
                        <td><?php echo $frqPcs[0]; ?></td>
                        <td align="middle"><input type="text" name="drug_freq_<?php echo $s; ?>" id="drug_freq_<?php echo $s; ?>" value="<?php echo $frqPcs[1]; ?>" style="text-align:center">
                            <input type="hidden" name="drug_freqId" id="drug_freq_Id" value="<?php echo $frqPcs[1]; ?>" style="text-align:center">
                            <input type="hidden" name="loop" id="drug_freq_Id" value="<?php echo$s; ?>" style="text-align:center">
                            <input type="hidden" name="id_<?php echo $s; ?>" id="id<?php echo $s; ?>" value="<?php echo$frqPcs[0]; ?>" style="text-align:center">
                        </td>

                        <td align="middle">
<!--                            <input name="but" id="but" type="submit" value="<?php echo$s; ?>" style='width:100px '/>-->
                            <button type='submit' name='but' id='but' value="<?php echo$s; ?>" style='width:100px'>Update</button>
                        </td>
                    </tr>

<?php $s++;} ?>

            </table>
        </form>

         <br/><br/>                   
        <div>
            <p><h1>Add New Frequency</h1></p>
        </div>
        <form action='http://localhost/eHealth_proj/index.php/Frequency_Controller/addFrequency' method='post'>
         <table class="table1">
                <thead>
                    <tr>
                        <th>Drug Frequency </th>
                        <th>Action</th>
                    </tr>
                    <tr>
                        <td align="middle"><input type="text" name="add_freq_db" id="add_freq_db" value="" style="text-align:center">
                        <td align="center"><input name="add" id="add" type="submit" value="Add Freqency"/></td>
                    </tr>
                </thead>
         </table>
        </form>

                    </div>
                    </div>
                </div>
                <div id="sidebar">
                </div>
            </div>
        </div>
        <?php $this->load->view('layout/Footer');?>
    </body>
</html>