<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <title></title>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.css'); ?>" media="all"/>

        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyRC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyDC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyBC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyUC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>validation.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Bootstrap/js/'; ?>bootstrap.js"></script>

    </head>

    <body onload="getCategoryListDC()">
        <div id="wrapper">
            <div id="header-wrapper">
                <?php $this->load->view('layout/Header');?>

                <div id="page">
                    <div id="content">
                        <div class="post">
<?php
        $currentDate = date("F j, Y");
        ?>
        <div>
            <p><h1>Drug Report For Low Stock In Hand</h1></p>
            <p><h1><?php echo$currentDate?></h1></p>
        </div>
        <form name="getcvs" action="report_pdfA" method="post">
            <div>
                <input type="submit" name="submitpdf" value="download pdf file" align="center"/>
            </div>
            <input type="hidden" name="count_basic_skills" value='<?php echo $details[1]; ?>'/>
            <input type="hidden" name="count_basic_skills" value='<?php echo $details[2]; ?>'/>
        </form>                    

        <form action='http://localhost/eHealth_proj/index.php/Report_Controller/requestMailDrug' method='post'>
            <p>
            <table class="table1">
                <thead>
                    <tr>
                        <th >Drug Name</th>
                        <th>Unit Type</th>
                        <th >Drug Category</th>
                        <th >Drug Price(Rs)</th>
                        <th >Drug Quantity</th>
                        <th >Send Mail</th>

                    </tr>


                </thead>

                <?php
//-------------------------------------------------------

                $dusr = new Report_Controller();
                $details = $dusr->drugReportNew();

//--------------------------------------------------------------------
                $s=0;
                foreach ($details as $value)  {

                    $drugPcs = explode(":", $details[$s]);
                    echo "<tr>";
                    echo "<td align='center'>$drugPcs[0]</td>";
                    echo "<td align='center'>$drugPcs[5]</td>";
                    echo "<td align='center'>$drugPcs[2]</td>";
                    echo "<td align='center'>$drugPcs[3]</td>";
                    if($drugPcs[4]<=$drugPcs[6])
                    {
                    echo "<td align='center' style='color:red'>$drugPcs[4]</td>";
                    }
                    else if($drugPcs[4]<=$drugPcs[7])
                    {
                    echo "<td align='center' style='color:orange'>$drugPcs[4]</td>";    
                    }
                    echo "<td align='center'>";
                   // echo "<input type='submit' name='qwe' id='qwe' value='" .$drugPcs[1]. "' style='text-align:center; width:100px'>";
                   echo "<button type='submit' name='asd' id='asd' value='" . $drugPcs[1] . "' style='width:100px'>Place Order </button>";
                    echo "</td>";
                    echo "</tr>";
                    $s++;
                }
                ?>
            </table>
        </form>
        <form name="getcvs" action="report_pdfA" method="post">
            <div>
                <input type="submit" name="submitpdf" value="download pdf file" align="center"/>
            </div>
            <input type="hidden" name="count_basic_skills" value='<?php echo $details[1]; ?>'/>
            <input type="hidden" name="count_basic_skills" value='<?php echo $details[2]; ?>'/>
        </form>

                    </div>
                    </div>
                </div>
                <div id="sidebar">
                </div>
            </div>
        </div>
        <?php $this->load->view('layout/Footer');?>
    </body>
</html>