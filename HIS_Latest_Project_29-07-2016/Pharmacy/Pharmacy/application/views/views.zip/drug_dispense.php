
<html>
    <head>
        <title> Drug Dispense</title>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.dataTables.columnFilter.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.validate.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/demo_table.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery.dataTables.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery.dataTables_themeroller.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/demo_table_jui.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.min.css'); ?>" media="all"/>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
  <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>dispense.js"></script>

    </head>
    <body>
	<div id="wrapper">
	<div id="header-wrapper">
	<?php $this->load->view('layout/Header');?>
	<div id="page">
<div id="content">
        <h1>Drug Dispense</h1>


<p>


  <div align="center" style="background-color:grey;color:blue;height:20px" >  </div>
  <form id="frmDispense" name="frmDispense" >
  <div align="center"  ><br/><b> <h4>Patient ID :<h4> </b>  <input type="text" id="pation" name="pation"  /> <input type="button" id="search" name="search" value="Search"/></div>
  </form>
   
</p>
<!-- prescrib table -->
<div id="prescribDiv"  style="width:1000px">
<div id="pait" ></div>
   <hr/>
   <div  style="background-color:#E5E5E5;">
<table align="center" cellpadding="0" cellspacing="0" border="0" id="prescribDataTable"
                                   class="table1 table-nomargin table-bordered dataTable table-striped table-hover table-condensed">
                                <thead>
                                <tr>
                                    <th width="8%" class="head0">Prescription ID</th>
                                    <th width="9%" class="head0">Create Date</th>
                                    <th width="11%" class="head0">Create User</th>
                                    <th width="10%" class="head0" style="width:15%">Prescription Date</th>
                                    <th width="12%" class="head0">Last UpdateUser</th>
                                    <th width="11%" class="head0">Min.Over Payment</th>
                                    <th width="10%" class="head0">Max.Over Payment</th>
                                    <th width="10%" class="head0">Min. Pawning Weight</th>
                                    <th width="9%" class="head0">Max. Pawning Weight</th>
									<th width="0%" class="head0">hdnVal_1</th>
                                    <th width="7%" class="head0">Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
							</div>
							</div>
						<!-- prescrib table -->	
							<!-- Items Table -->
							<div id="itembDiv" style="width:1000px">
							<div><b> Drugs List </b>  </div>
   <hr/>
    <div style="background-color:#E5E5E5;">
<table  cellpadding="0" cellspacing="0" border="0" id="itemDataTable"
                                   class="table1 table-nomargin table-bordered dataTable table-striped table-hover table-condensed">
                                <thead>
                                <tr>
                                    <th width="8%" class="head0">Drug Description</th>
                                    <th width="9%" class="head0">Dosage</th>
                                    <th width="11%" class="head0">Frequency</th>
                                    <th width="10%" class="head0" style="width:15%">Period</th>
                                    <th width="12%" class="head0">Quantity</th>
                                    <th width="11%" class="head0">drugID</th>
                                    <th width="10%" class="head0">Max.Over Payment</th>
                                    <th width="10%" class="head0">Min. Pawning Weight</th>
                                    <th width="9%" class="head0">Max. Pawning Weight</th>
									<th width="0%" class="head0">hdnVal_1</th>
                                    <th width="7%" class="head0">Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
							</div>
							<hr/>
							<br/>
							<div align="center"><h4><input type="button" id="back" name="back" value="<< Back "/>&nbsp;&nbsp;&nbsp;<input type="button" id="dispense" name="dispense" value="Dispense"/></h4></div>
							</div>
							<!--  Items Table -->
							</div>
							</div>
							 <div id="sidebar">
                </div>
		</div>					
		</div>		
 <?php $this->load->view('layout/Footer');?>		


    </body>
</html>