
<html>
    <head>
        <title> Drug Dispense</title>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery-1.9.1.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jqueryui.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.dataTables.columnFilter.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.validate.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/demo_table.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery.dataTables.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery.dataTables_themeroller.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/demo_table_jui.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.min.css'); ?>" media="all"/>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
   <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery-ui.css'); ?>" media="all"/>
  
<script>
$(function() {
//$( "#datepicker" ).datepicker();
$("#datepicker").datepicker({ dateFormat: "yy-mm-dd" }).val();
$( "#btnReportView" ).click(function(){
$('#view_report').load('<?php echo site_url('Dispense_Drug_Reports/viewReport'); ?>'+'?date='+$("#datepicker").val());
});

$("#view__pdf_report").hide();
$( "#create_pdf" ).click(function(){
 $("#view__pdf_report").attr("src", "<?php echo site_url('Dispense_Drug_Reports/viewReportPdf'); ?>"+"?date="+$("#datepicker").val());
});


});

/*
$(function() {
    $( "#datepicker" ).datepicker();
    $( "#format" ).change(function() {
      $( "#datepicker" ).datepicker( "option", "dateFormat", $( this ).val() );
    });
  });

*/

</script>
    </head>
    <body>
	<div id="wrapper">
	<div id="header-wrapper">
	<?php $this->load->view('layout/Header');?>
	<div id="page">
<div id="content">
        <h1>Drug Dispense Report</h1>


<p>



   Date: <input type="text" id="datepicker" name="datepicker" />
    <input type="button" id="btnReportView" name="btnReportView" value="View Report" /><input type="button" id="create_pdf" name="create_pdf" value="Create PDF" />
<hr/>  
  <div id="view_report"></div>
   
    <iframe id="view__pdf_report"></iframe>
</p>

							</div>
							</div>
							 <div id="sidebar">
                </div>
		</div>					
		</div>		
 <?php $this->load->view('layout/Footer');?>		


    </body>
</html>