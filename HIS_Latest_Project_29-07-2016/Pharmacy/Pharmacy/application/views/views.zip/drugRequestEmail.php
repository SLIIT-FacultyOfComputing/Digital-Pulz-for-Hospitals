<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <title></title>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.css'); ?>" media="all"/>

        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyRC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyDC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyBC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyUC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>validation.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Bootstrap/js/'; ?>bootstrap.js"></script>

    </head>

    <body onload="getCategoryListDC()">
        <div id="wrapper">
            <div id="header-wrapper">
                <?php $this->load->view('layout/Header');?>

                <div id="page">
                    <div id="content">
                        <div class="post">
<div>
            <p><h1>Drug Request Mail Sender</h1></p>
        </div>
        <?php
       ( $s = $_POST['asd']);
        $st = substr($s, 0, 4);
        //echo $st;
        //-------------------------------------------------------

        $dusr = new Report_Controller();
        $details = $dusr->drugReportNew();

        //--------------------------------------------------------------------
        $id = 0;
        $name = 0;
        $cat = 0;
        $price = 0;
        $quty = 0;

        $s=0;
        foreach ($details as $value) {
            $drugPcs = explode(":", $details[$s]);

            if ($drugPcs[1] === $st) {

                $name = $drugPcs[0];
                $cat = $drugPcs[2];
                $price = $drugPcs[3];
                $quty = $drugPcs[4];
            }
            $s++;
        }
        $text = "" . "\n"
                . "Dear Officer" . "\n"
                . "The Quantity of the bellow Drug is Low." . "\n"
                . "Name     :" . $name . "\n"
                . "Catagary :" . $cat . "\n"
                . "Price(Rs)    :" . $price . "\n"
                . "Quantity in Hand :" . $quty . "\n"
                . "Please be kind enough to send us new Stock for the above mentioned Drug." . "\n"
                . "" . "\n"
                . "" . "\n"
                . "Best Regards" . "\n"
                . "Chief Pharmasist" . "\n";

        $subject = "Drug Reorder Request For " . $name;
        ?>

        <form action='http://localhost/eHealth_proj/index.php/Report_Controller/sendRequestMail' method='post'>
            <table class="table1" width="100px">
                <tr>
                    <th>From :</th>
                    <td><input  type="text" name="from" id="from" value="ehealthpharmacy111@gmail.com" style="width:830px " ></td>
                </tr>
                <tr>
                    <th>To :</th>
                    <td><input  type="text" name="to" id="to" value="mushthaq_99@hotmail.com" style="width:830px " ></td>
                </tr>
                <tr>
                    <th >Subject :</th>
                    <td><input  type="text" name="subject" id="subject" value="<?php echo $subject ?>" style="width:830px "</td>
                </tr>
                <tr>
                    <th>Content :</th>
                    <td><textarea name="cont" id="cont" rows="15" cols="101">
                            <?php echo $text ?>
                        </textarea></td>
                </tr>
            </table>

            <div align="center">
                <input type="submit" name="submitpdf" value="SEND" align="center"/>
                <input type="hidden" name="id" id="id" value="<?php echo $st; ?>"/>
            </div>
        </form>



        <br><br>
        <div>
            <p><h1>Mail History For Selected Drug</h1></p>
        </div>
        <table class="table1" width="70%">
                <thead>
                    <tr>
                        <th>Content</th>
                        <th>Date</th>
                    </tr>


                </thead>
        <?php
//-------------------------------------------------------
                            $dusrMail = new Report_Controller();
                            $detailsMailHi = $dusrMail->getMailHistory();
                            $s=0;

                            foreach ($detailsMailHi as $value) {
                                $drugPcsMail = explode("@", $detailsMailHi[$s]);
                                $s++;
                                if($drugPcsMail[0] == $st){
                                         //--------------------------------------------------------------------
        ?>
                <tr>
                        <td><?php echo $drugPcsMail[1]?></td>
                        <td><?php echo $drugPcsMail[2]?></td>
                 </tr>
        <?php }}?>
        </table>

                    </div>
                    </div>
                </div>
                <div id="sidebar">
                </div>
            </div>
        </div>
        <?php $this->load->view('layout/Footer');?>
    </body>
</html>