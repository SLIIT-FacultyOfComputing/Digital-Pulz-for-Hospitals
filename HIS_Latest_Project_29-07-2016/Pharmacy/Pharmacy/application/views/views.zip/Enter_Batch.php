<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <title></title>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/css/stylesheet.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery.datepick.css'); ?>" media="all"/>
        <link rel='stylesheet' type='text/css' href='http://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css'/>
        
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery.js"></script>
        
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>script.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jq_pharmacy.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyRC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyDC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyBC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyUC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>validation.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Bootstrap/js/'; ?>bootstrap.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery.datepick.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery-ui.min.js"></script>
        
</head>

    <body onload="getCategoryListBC()">
<div id="wrapper">
            <div id="header-wrapper">
                <?php $this->load->view('layout/Header');?>

                <div id="page">
                    <div id="content">
                       <div class="post">
                            <h2 class="title"><a href="#">Select Drug Category</a></h2>
                            <div class="entry">
                                Drug Category :<br/>
                                <select style="width:500px" id="categoryDropDownBC" name="categoryDropDownBC" onchange="getDrugByCategoryBC()">
                                    <option value="default" selected="selected">All</option>
                                </select>
                                <img id="imgid" style="visibility: hidden;" src="<?php echo base_url('/Contents/images/Loading.gif'); ?>" width="30" height="30"/>
                                <br></br>
                             </div>
                        </div>
                        <div class="post" id="post_drugName_dd_BC">
                            <h2 class="title" ><a href="#">Add Received Drug</a></h2>
                            <div class="entry" >
                                Drug Name :<br/>
                                <select style="width:500px" id="drugNameDropDownBC" name="drugNameDropDownBC">
                                </select>
                                <br></br>
                               Batch No :<br/>  
                               <input  type="text" name="batchNoValueBC" id="batchNoValueBC" onkeyup="validateField(this.value,'batcherror')"/><span id="batcherror"></span>
                               <br></br>
                               <label>Type</label> :<br/>
                               <select id="typeDropDownBC" name="typeDropDownBC" onchange="getDetailsFromType()">
                                   <option value="" disabled="disabled" selected="selected">Please select a type</option>
                                   <option value="Cartoons">Cartoons</option>
                                   <option value="Bottles">Bottles</option>
                               </select>
                                <br></br>
                                <p id="itemspaceBC"></p>
                                <br/>
                                <p id="cartoonspaceBC"></p>
                                <br/>
                                <p id="quantityspaceBC"></p>
                                <br/>
                               Quantity :<br/> 
                               <input  type="text" disabled="disabled" name="quantityValueBC" id="quantityValueBC" onkeyup="validateQty(this.value,'qtyerror')" /><span id="qtyerror"></span>
                               <br></br>
                               Manufacture Date : <br/> 
                               <input  type="text" name="manufactureDateValueBC" id="manufactureDateValueBC" readonly="true"/><span id="manerror"></span>

                                <br></br>
                               Expire date :<br/> 
                               <input  type="text" name="expireDateValueBC" id="expireDateValueBC" readonly="true" /><span id="experror"></span>

                                <br></br>
                                <input type="submit" value="Add Batch" onclick="addDrugBatchBC()"/>
                                <img id="imgbuttonid" style="visibility: hidden;" src="<?php echo base_url('/Contents/images/Loading.gif'); ?>" width="30" height="30"/>
                                
                            </div>
                        </div>
                    </div>	
                </div>
                <div id="sidebar">
                </div>
            </div>
        </div>

        <?php $this->load->view('layout/Footer');?>
</body>
</html>
