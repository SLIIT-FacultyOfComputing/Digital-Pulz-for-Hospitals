
<html>
    <head>
        <title> Drug Dosages</title>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.min.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.dataTables.columnFilter.js"></script>
<script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>jquery.validate.js"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/demo_table.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery.dataTables.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/jquery.dataTables_themeroller.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/demo_table_jui.css'); ?>" media="all"/>
<link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.min.css'); ?>" media="all"/>
  <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
  <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/';?>dosage.js"></script>

    </head>
    <body>
	<div id="wrapper">
	<div id="header-wrapper">
	<?php $this->load->view('layout/Header');?>
	<div id="page">
<div id="content">
        <h1>Drug Dosages</h1>


<p>


  <div align="center" style="background-color:grey;color:blue;height:20px" >  </div>
  <form id="frmFrequency" name="frmFrequency" >
  <div  id="fields" >
   <div align="left"> 
   <h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="button" id="back" name="back" value="<< Back"/></h4></div>
  <input type="hidden" id="dosId" name="dosId"  /> 
  <br/>
  <b> <h4>Dosage :<h4> </b>  <input type="text" id="dosage" name="dosage"  /> <br/>
   <b> <h4>Is Active :<h4> </b>  <select type="text" id="recordStatus" name="recordStatus"  >  
   <option value="1">Active</option>
    <option value="0">In-Active</option>
   </select>
   <br/>
  <input type="button" id="save" name="save" value="Save"/></div>
  </form>
   
</p>

<!-- dosage table -->
<div id="dosageDiv"  style="width:1000px">
 <div align="right"><h4><input type="button" id="addNew" name="addNew" value="+ Add New Dosage"/></h4></div>
<div id="pait" ></div>
   <hr/>
   <div  style="background-color:#E5E5E5;">
<table align="center" cellpadding="0" cellspacing="0" border="0" id="dosageDataTable"
                                   class="table1 table-nomargin table-bordered dataTable table-striped table-hover table-condensed">
                                <thead>
                                <tr>
                                    <th  class="head0">Dosage</th>
                                    <th  class="head0">Status</th>
									<th  class="head0">record_status</th>
									<th  class="head0">record_id</th>
                                    <th  class="head0">Action</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
							</div>
							</div>
						<!-- dosage table -->	

							</div>
							</div>
							 <div id="sidebar">
                </div>
		</div>					
		</div>		
 <?php $this->load->view('layout/Footer');?>		


    </body>
</html>