<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <title></title>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.css'); ?>" media="all"/>

        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jq_pharmacy.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyRC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyDC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyBC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyUC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>validation.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Bootstrap/js/'; ?>bootstrap.js"></script>

</head>

<body onload="getCategoryListDCUpdate()">
<div id="wrapper">
            <div id="header-wrapper">
                <?php $this->load->view('layout/Header');?>
                <div id="page">
                    <div id="content">
                        <div class="post" id="post_drugAdd_DC"">
                            <h2 class="title"><a href="#">Update The Drug</a></h2>
                            <div class="entry">
                                Drug Category :  <select style="width:500px; margin-left:16px" style="" id="categoryDropDownDC" name="categoryDropDownDC" onchange="getDrugByCategoryDCUpdate()">
                                    <option value="default" selected="selected">All</option>
                                </select>
                                <img id="imgid" style="visibility: hidden;" src="<?php echo base_url('/Contents/images/Loading.gif'); ?>" width="30" height="30"/>
                                <br></br>
                                Drug Name : <select style="width:500px; margin-left: 36px" id="drugNameDropDownDC" name="drugNameDropDownDC" onchange="getDrugDetailsByDNameDC()">
                                </select>
                                <img id="imgid" style="visibility: hidden;" src="<?php echo base_url('/Contents/images/Loading.gif'); ?>" width="30" height="30"/>
                                <br></br>
                                Drug Type : <input style="margin-left: 43px" type="text" name="drugTypeDC" id="drugTypeDC" disabled="disabled"/>  
                                <br></br>
                               Price(Rs) : <input style="margin-left: 45px" type="text" name="priceValueDC" id="priceValueDC" onkeyup="validatePrice(this.value,'priceerror')"/><span id="priceerror"></span>
                                <br></br>
                               Reorder Level : <input style="margin-left: 20px" type="text" name="reorderValueDC" id="reorderValueDC" onkeyup="validateQty(this.value,'reordererror')"/><span id="reordererror"></span>
                                <br></br>
                               Danger Level : <input style="margin-left: 25px" type="text" name="dangerValueDC" id="dangerValueDC" onkeyup="validateQty(this.value,'dangererror')"/><span id="dangererror"></span>
                                <br></br>
                                Remarks : <input style="margin-left: 50px" type="text" name="remarksValueDC" id="remarksValueDC" onkeyup="validateField(this.value,'remerror')"/><span id="remerror"></span>
                                <br></br>
                                <input type="submit" value="Update Drug" onclick="addDrugDC()"/>
                                <img id="imgbuttonid" style="visibility: hidden;" src="<?php echo base_url('/Contents/images/Loading.gif'); ?>" width="30" height="30"/>
                                <p id="tablespaceDC"></p>
                            </div>
                        </div>                      
                    </div>	
                </div>
                <div id="sidebar">
                </div>
            </div>
        </div>

        <?php $this->load->view('layout/Footer');?>
</body>
</html>
