<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>

        <title></title>

        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Contents/cssnew/ehealth.css'); ?>" media="all"/>
        <link rel="stylesheet" type="text/css" href="<?php echo base_url('/Bootstrap/css/bootstrap.css'); ?>" media="all"/>

        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jquery.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>common.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyRC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyDC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyBC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>jqPharmacyUC.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Scripts/JS/'; ?>validation.js"></script>
        <script type="text/javascript" src="<?php echo base_url() . 'Bootstrap/js/'; ?>bootstrap.js"></script>

    </head>

    <body onload="getCategoryListDC()">
        <div id="wrapper">
            <div id="header-wrapper">
                <?php $this->load->view('layout/Header');?>

                <div id="page">
                    <div id="content">
                       <div class="post">
                           <h2 class="title"><a href="#">Select Drug Category</a></h2>
                            <div class="entry">  
                                Drug Category : <br/>
                                <select style="width: 600px" id="categoryDropDownDC" name="categoryDropDownDC" onchange="getDrugByCategoryDC() ">
                                    <option value="default" selected="selected">Select</option>
                                </select>
                                <img id="imgid" style="visibility: hidden;" src="<?php echo base_url('/Contents/images/Loading.gif'); ?>" width="30" height="30"/>
                                <br><br>
                                        <p id="drugspaceDC"></p>
                                        <br></br>
                                        <p id="tablespaceDC"></p>
                                        
                             </div>
                        </div>
                        <div class="post" id="post_drugDetails_tbl_DC" style="visibility: hidden;">
                            <div class="entry">               
                                   <p id="pagespaceDC"></p>
                                   <a name="detailsPost"></a>
                            </div>
                        </div>

                    </div>	
                </div>
                <div id="sidebar">
                </div>
            </div>
        </div>
        <?php $this->load->view('layout/Footer');?>
    </body>
</html>