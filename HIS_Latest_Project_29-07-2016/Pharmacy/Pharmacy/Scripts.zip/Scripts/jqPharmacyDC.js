function getCategoryListDC() {
    $.ajax({
        url: 'http://localhost/eHealth_proj/index.php/Drug_controller/getCatList',
        type: 'POST',
        crossDomain: true,
        success: function(data) {
            var json_parsed = $.parseJSON(data);
            for (var i = 0; i < json_parsed.length; i++) {
                var newOption = $('<option id='+json_parsed[i]['dCategoryId']+'>');
                newOption.attr('value', json_parsed[i]['dCategory']).text(json_parsed[i]['dCategory']);
                $('#categoryDropDownDC').append(newOption);
                //alert(json_parsed[i]['dCategoryId']);
            }


        }
    });

}

function getDrugByCategoryDC(){

     document.getElementById("post_drugDetails_tbl_DC").style.visibility = "hidden";

     var drugName_ddcontents = "";
         drugName_ddcontents += "Drug Name :";
         drugName_ddcontents += "</br>"
         drugName_ddcontents += "<select style="+"width: 500px"+" id=drugNameDropDownDC name=drugNameDropDownDC onchange=createDrugOptiontableDC() >";
         drugName_ddcontents += "<option value=default selected=selected>Select</option>";
         drugName_ddcontents += "</select>";

     document.getElementById("drugspaceDC").innerHTML = drugName_ddcontents;

    var val;
    val = $("#categoryDropDownDC option:selected").text();
    $.ajax({
        url: 'http://localhost/eHealth_proj/index.php/Drug_controller/getDrugList/'+val,
        type: 'POST',
        crossDomain: true,
                success: function(data) {

            var json_parsed = $.parseJSON(data);
            for (var i = 0; i < json_parsed.length; i++) {
                var newOption = $('<option>');
                newOption.attr('value', json_parsed[i]['dName']).text(json_parsed[i]['dName']);
                $('#drugNameDropDownDC').append(newOption);
                 }
            }
    });
}
function createDrugOptiontableDC() {

    document.getElementById("post_drugDetails_tbl_DC").style.visibility = "hidden";
    var val;
    val = $("#drugNameDropDownDC option:selected").text();
            var j=1;
            var tablecontents = "";

            tablecontents = "<table class=table1 id=tablecontent>";
            tablecontents += "<thead>";
            tablecontents += "<tr>";
            tablecontents += "<th>Name</th>";
            tablecontents += "<th>Edit</th>";
            tablecontents += "<th>View</th>";
            tablecontents += "<th>Delete</th>";
            tablecontents += "</tr>";
            tablecontents += "</thead>";
            tablecontents += "<tbody>";

            tablecontents += "<tr>";
            tablecontents += "<td>" + val + "</td>";
            tablecontents += "<td onclick=getDataToEditDC("+j+")>" + "<a href='#detailsPost'>" + "Edit" + "</a></td>";
            tablecontents += "<td onclick=getDataToViewDC("+j+")>" + "<a href='#detailsPost'>" + "View" + "</a></td>";
            tablecontents += "<td onclick=test_onclick()>" + "<a href='#'>" + "Delete" + "</a></td>";
            tablecontents += "</tr>";

            tablecontents += "</tbody>";
            tablecontents += "</table>";
            document.getElementById("tablespaceDC").innerHTML = tablecontents;

}


function getDataToEditDC(rowNumber) {

    document.getElementById("post_drugDetails_tbl_DC").style.visibility = "visible";
    $row_Number = rowNumber;
    var drugNameFromColumn;

    $('#tablecontent tr td').each(function(){
         drugNameFromColumn  = $("#tablecontent tr:nth-child("+rowNumber+") td:nth-child(1)").text()

         });

    var myOrderString = drugNameFromColumn;

    $.ajax({
        url: 'http://localhost/eHealth_proj/index.php/Drug_controller/getDrugDetails',
        type: 'POST',
        crossDomain: true,
        data: {"myOrderString": myOrderString},  // fix: need to append your data to the call
        success: function (data) {

           var json_parsed = $.parseJSON(data);
           var s1,s2,s3,s4,s5,s6,s0;
           s0=json_parsed[0]["dSrNo"];
           s1=json_parsed[0]["categories"]["dCategory"];
           s2=json_parsed[0]["dName"];
           s3=json_parsed[0]["dCreateUser"];
           s4=json_parsed[0]["dLastUpdate"];
           s5=json_parsed[0]["dPrice"];
           s6=json_parsed[0]["dQty"];
           createDrugUpdateTblDC(s0,s1,s2,s3,s4,s5,s6);

        }
    });

}

function getDataToViewDC(rowNumber) {

    document.getElementById("post_drugDetails_tbl_DC").style.visibility = "visible";
    var drugNameFromColumn;

    $('#tablecontent tr td').each(function(){
         drugNameFromColumn  = $("#tablecontent tr:nth-child("+rowNumber+") td:nth-child(1)").text()

      });

    var myOrderString = drugNameFromColumn;

    $.ajax({
        url: 'http://localhost/eHealth_proj/index.php/Drug_controller/getDrugDetails',
        type: 'POST',
        crossDomain: true,
        data: {"myOrderString": myOrderString},  // fix: need to append your data to the call
        success: function (data) {
           //alert(data);
           var json_parsed = $.parseJSON(data);
           var s1,s2,s3,s4,s5,s6,s0;
           s0=json_parsed[0]["dSrNo"];
           s1=json_parsed[0]["categories"]["dCategory"];
           s2=json_parsed[0]["dName"];
           s3=json_parsed[0]["dCreateUser"];
           s4=json_parsed[0]["dLastUpdate"];
           s5=json_parsed[0]["dPrice"];
           s6=json_parsed[0]["dQty"];
           createviewTblDC(s0,s1,s2,s3,s4,s5,s6);

        }
    });

}

function createviewTblDC(sr,category,name,createUser,LastUpdated,price,quantity){

    $sr_globe = sr;
    var pagecontent = "";

    pagecontent = "<table class=table1 id=pagetable>";
    pagecontent += "<thead>";
    pagecontent += "<tr>";
    pagecontent += "<th>Drug Details</th>";
    pagecontent += "<th>Values to the date</th>";
    pagecontent += "</tr>";
    pagecontent += "</thead>";
    pagecontent += "<tbody>";

    pagecontent += "<tr>";
    pagecontent += "<td>SR No</td>";
    pagecontent += "<td name=sr_val id=sr_val >"+sr+"</td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Category</td>";
    pagecontent += "<td>"+category+"</td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Name</td>";
    pagecontent += "<td>"+name+"</td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Create User</td>";
    pagecontent += "<td>"+createUser+"</td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Last Updated</td>";
    pagecontent += "<td>"+LastUpdated+"</td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Price</td>";
    pagecontent += "<td>"+price+"</td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Quantity</td>";
    pagecontent += "<td>"+quantity+"</td>";
    pagecontent += "</tr>";

    pagecontent += "</tbody>";
    pagecontent += "</table>";



   document.getElementById("pagespaceDC").innerHTML = pagecontent;
}

function createDrugUpdateTblDC(sr,category,name,createUser,LastUpdated,price,quantity){

    $sr_globe = sr;
    var pagecontent = "";

    pagecontent = "<table class=table1 id=pagetable>";
    pagecontent += "<thead>";
    pagecontent += "<tr>";
    pagecontent += "<th>Drug Details</th>";
    pagecontent += "<th>Values to the date</th>";
    pagecontent += "</tr>";
    pagecontent += "</thead>";
    pagecontent += "<tbody>";

    pagecontent += "<tr>";
    pagecontent += "<td>Category</td>";
    pagecontent += "<td><input value="+category+" type=text name=categoryValueDC id=categoryValueDC /></td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Name</td>";
    pagecontent += "<td><input value="+name+" type=text name=nameValueDC id=nameValueDC /></td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Price</td>";
    pagecontent += "<td><input value="+price+" type=number name=priceValueDC id=priceValueDC /></td>";
    pagecontent += "</tr>";

    pagecontent += "<tr>";
    pagecontent += "<td>Quantity</td>";
    pagecontent += "<td><input value="+quantity+" type=number name=quantityValueDC id=quantityValueDC /></td>";
    pagecontent += "</tr>";

    pagecontent += "</tbody>";
    pagecontent += "</table>";

    pagecontent += "<input type=submit value=Update onclick=getAllDataDC()>";
    document.getElementById("pagespaceDC").innerHTML = pagecontent;
}


function getAllDataDC() {

var cat_val_chckd,nam_val_chckd,user_val_chckd,price_val_chckd,qty_va_chckd;



   cat_val_chckd = $("#categoryValueDC").val();
   nam_val_chckd = $("#nameValueDC").val();  
   price_val_chckd = $("#priceValueDC").val();
   qty_va_chckd = $("#quantityValueDC").val();


var r=confirm("Are you sure you want to update the following data ?");
if (r==true)
    {
$.ajax({
        url: 'http://localhost/eHealth_proj/index.php/Drug_controller/updateDrug',
        type: 'POST',
        crossDomain: true,
        data: {"dsr":$sr_globe ,"dcat":cat_val_chckd , "dname":nam_val_chckd ,"dprice":price_val_chckd,"dqty":qty_va_chckd},
        success: function (data) {
        alert(data);
        getDataAfterEditDC(1);

        }
    });
    }
    else{
        alert("canceled update");
    }
    
}

function getDataAfterEditDC(rowNumber) {

    var drugNameFromColumn;

        $('#tablecontent tr td').each(function(){
         drugNameFromColumn  = $("#tablecontent tr:nth-child("+rowNumber+") td:nth-child(1)").text()

    });

    var myOrderString = drugNameFromColumn;

    $.ajax({
        url: 'http://localhost/eHealth_proj/index.php/Drug_controller/getDrugDetails',
        type: 'POST',
        crossDomain: true,
        data: {"myOrderString": myOrderString},
        success: function (data) {
           var json_parsed = $.parseJSON(data);
           var s1,s2,s3,s4,s5,s6,s0;
           s0=json_parsed[0]["dSrNo"];
           s1=json_parsed[0]["categories"]["dCategory"];
           s2=json_parsed[0]["dName"];
           s3=json_parsed[0]["dCreateUser"];
           s4=json_parsed[0]["dLastUpdate"];
           s5=json_parsed[0]["dPrice"];
           s6=json_parsed[0]["dQty"];
           createviewTblDC(s0,s1,s2,s3,s4,s5,s6);

        }
    });

}
function addDrugDC(){

    var drugName  = document.getElementById("drugNameValueDC").value;
    var drugCat   = $("#categoryDropDownDC option:selected").text();
    var drugCatId = $("#categoryDropDownDC option:selected").attr('id');
    var drugType  = $("#drugTypeDropDownDC option:selected").text();
    var remarks   = document.getElementById("remarksValueDC").value;
    var price     = document.getElementById("priceValueDC").value;
    var drugDosage  = $("#dosageDropDownDC option:selected").text();
    var drugDosageId = $("#dosageDropDownDC option:selected").attr('id');
    var drugFrequency  = $("#frequencyDropDownDC option:selected").text();
    var drugFrequencyId = $("#frequencyDropDownDC option:selected").attr('id');
    var drugReorder  = document.getElementById("reorderValueDC").value;
    var drugDanger  = document.getElementById("dangerValueDC").value;
    var dnameError  = $("#dnameerror").text();
    var remarksError  = $("#remerror").text();
    var priceError  = $("#priceerror").text();
    var dosageError  = $("#dosageerror").text();
    var frequencyError  = $("#frequencyerror").text();
    var reorderError  = $("#reordererror").text();
    var dangerError  = $("#dangererror").text();
    
    //alert(drugCat);
    if(drugName.length==0 || remarks.length==0 || price.length==0 || drugDosage.length==0 || drugFrequency.length==0 || drugReorder.length==0 || drugDanger.length==0)
    {
        alert("Please Fill all the Fields");
    }
    else if(dnameError.length !=0 || remarksError.length !=0 || priceError.length != 0 || dosageError.length != 0 || frequencyError.length !=0 || dangerError.length != 0 || reorderError.length != 0)
    {
        alert("Some Fields are Invalid!!!");
    }
    else
    {
    $.ajax({
            url: 'http://localhost/eHealth_proj/index.php/Drug_controller/addDrug',
            type: 'POST',
            crossDomain: true,
            data: {"drugName":drugName ,"drugCat":drugCat, "drugCatId":drugCatId, "drugType":drugType,
                   "remarks":remarks,"price":price,"drugDosage":drugDosage, "drugDosageId":drugDosageId,
                   "drugFrequency":drugFrequency, "drugFrequencyId":drugFrequencyId, "drugReorder":drugReorder,"drugDanger":drugDanger },
            success: function(data) {
                 alert(data);
                                 }
         });
    }
}



