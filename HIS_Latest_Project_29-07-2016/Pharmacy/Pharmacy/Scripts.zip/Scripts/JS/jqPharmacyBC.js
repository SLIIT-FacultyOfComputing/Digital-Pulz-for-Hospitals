function getCategoryListBC() {
    document.getElementById("imgid").style.visibility = "visible";
    $.ajax({
        url: 'http://localhost/eHealth_proj/index.php/Batch_controller/getCatList',
        type: 'POST',
        crossDomain: true,
        success: function(data) {
            data = trimData(data);
            var json_parsed = $.parseJSON(data);
            for (var i = 0; i < json_parsed.length; i++) {
                var newOption = $('<option>');
                newOption.attr('value', json_parsed[i]['dCategory']).text(json_parsed[i]['dCategory']);
                $('#categoryDropDownBC').append(newOption);
            }

        }
    });
    
    $.ajax({
            url: 'http://localhost/eHealth_proj/index.php/Batch_controller/getDrugNames',
            type: 'POST',
            crossDomain: true,
                    success: function(data) {
                data = trimData(data);
                var json_parsed = $.parseJSON(data);
                for (var i = 0; i < json_parsed.length; i++) {
                    var newOption = $('<option id='+json_parsed[i]['dSrNo']+'>');
                    newOption.attr('value', json_parsed[i]['dName']).text(json_parsed[i]['dName']);
                    $('#drugNameDropDownBC').append(newOption);
                     }
                     
                }
        });
       document.getElementById("imgid").style.visibility = "hidden";

}

function getDrugByCategoryBC(){

//     var drugName_ddcontents = "";
//         drugName_ddcontents += "<select id=drugNameDropDownBC name=drugNameDropDownBC >";
//         drugName_ddcontents += "<option value=default selected=selected>Select</option>";
//         drugName_ddcontents += "</select>";
//
//     document.getElementById("drugspaceBC").innerHTML = drugName_ddcontents;
//
//     document.getElementById("post_drugName_dd_BC").style.visibility = "visible";
    //document.getElementById("imgid").style.visibility = "visible";
    $('#drugNameDropDownBC').empty();
    var val;
    val = $("#categoryDropDownBC option:selected").text();
    if (val == "All")
    {
        $.ajax({
            url: 'http://localhost/eHealth_proj/index.php/Batch_controller/getDrugNames',
            type: 'POST',
            crossDomain: true,
                    success: function(data) {
                data = trimData(data);
                var json_parsed = $.parseJSON(data);
                for (var i = 0; i < json_parsed.length; i++) {
                    var newOption = $('<option>');
                    newOption.attr('value', json_parsed[i]['dName']).text(json_parsed[i]['dName']);
                    $('#drugNameDropDownBC').append(newOption);
                     }
                     document.getElementById("imgid").style.visibility = "hidden";
                }
        });
    }
    else
    {
        $.ajax({
            url: 'http://localhost/eHealth_proj/index.php/Batch_controller/getDrugList/'+val,
            type: 'POST',
            crossDomain: true,
                    success: function(data) {
                data = trimData(data);
                var json_parsed = $.parseJSON(data);
                for (var i = 0; i < json_parsed.length; i++) {
                    var newOption = $('<option>');
                    newOption.attr('value', json_parsed[i]['dName']).text(json_parsed[i]['dName']);
                    $('#drugNameDropDownBC').append(newOption);
                     }
                     document.getElementById("imgid").style.visibility = "hidden";
                }
        });
    }
}

function getDetailsFromType(){
    
    var type   = $("#typeDropDownBC option:selected").text();
    var drugName_ddcontents = "";

         
    if(type == "Cartoons" || type == "Bottles")
        {
         drugName_ddcontents += "<label style= background-color: 00FFFF >Content</label>";
         drugName_ddcontents += "<br/>"
         drugName_ddcontents += "<select onchange=getContentDetails() id=contentTypeDropDownBC name=contentTypeDropDownBC >";
         drugName_ddcontents += "<option value=default selected=selected>Select</option>";
         drugName_ddcontents += "<option >Tablets</option>";
         drugName_ddcontents += "<option >Liquid</option>";
         drugName_ddcontents += "</select>";
        }

//    else if(type == "Bottles")
//        {
//         drugName_ddcontents += "<label style= background-color: #00FFFF >Number of Bottles</label>";
//         drugName_ddcontents += "<br/>"
//         drugName_ddcontents += "<td><input type=number name=numOfBottlesTypeValueDC id=numOfBottlesTypeValueDC /></td>";
//         drugName_ddcontents += "<br></br>";
//         drugName_ddcontents += "<label style= background-color: #00FFFF >Number of tablets per 100g</label>";
//         drugName_ddcontents += "<br/>"
//         drugName_ddcontents += "<td><input type=number name=numberOfTabletsValueDC id=numberOfTabletsValueDC /></td>";
//         drugName_ddcontents += "<br></br>"
//         drugName_ddcontents += "<label style= background-color: #00FFFF >Weight of a bottle in grams</label>";
//         drugName_ddcontents += "<br/>"
//         drugName_ddcontents += "<td><input type=number name=weightOfBottleValueDC id=weightOfBottleValueDC /></td>";
//        }
     document.getElementById("itemspaceBC").innerHTML = drugName_ddcontents;
     document.getElementById("cartoonspaceBC").innerHTML = "";
     document.getElementById("quantityspaceBC").innerHTML = "";
     
}

function getContentDetails(){
    
    var content   = $("#contentTypeDropDownBC option:selected").text();
    var type   = $("#typeDropDownBC option:selected").text();
    var drugName_ddcontents ="";
    
    if(type=="Bottles" && content=="Tablets")
    {
        drugName_ddcontents = "<label style= background-color: #00FFFF >Number of Bottles</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfBottlesContentValueDC id=numOfBottlesContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<label style= background-color: #00FFFF >Number of Tablets per Bottle</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfTabletsContentValueDC id=numOfTabletsContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<input type=submit value='Calculate Quantity' onclick=calculateQuantityBT()>";
        drugName_ddcontents += "<br></br>";
    }
    else if(type=="Bottles" && content=="Liquid")
    {
        drugName_ddcontents = "<label style= background-color: #00FFFF >Number of Bottles</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfBottlesContentValueDC id=numOfBottlesContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<input type=submit value='Calculate Quantity' onclick=calculateQuantityBL()>";
        drugName_ddcontents += "<br></br>";
    }
    else if(type=="Cartoons" && content=="Liquid")
    {
        drugName_ddcontents = "<label style= background-color: #00FFFF >Number of Cartoons</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfCartoonsContentValueDC id=numOfCartoonsContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<label style= background-color: #00FFFF >Number of Bottles per Cartoon</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfBottlesContentValueDC id=numOfBottlesContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<input type=submit value='Calculate Quantity' onclick=calculateQuantityCL()>";
        drugName_ddcontents += "<br></br>";
    }
    else if(type=="Cartoons" && content=="Tablets")
    {
        drugName_ddcontents += "<label style= background-color: 00FFFF >Content Type</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<select onchange=getContentTypeDetails() id=contentDropDownBC name=contentDropDownBC >";
        drugName_ddcontents += "<option value=default selected=selected>Select</option>";
        drugName_ddcontents += "<option >Bottles</option>";
        drugName_ddcontents += "<option >Cards</option>";
        drugName_ddcontents += "</select>";
    }
//   if(content == "cards")
//       {
//
//         drugName_ddcontents += "<label style= background-color: #00FFFF >Number of cards per cartoon</label>";
//         drugName_ddcontents += "<br/>"
//         drugName_ddcontents += "<td><input type=number name=numOfCardsValueDC id=numOfCardsValueDC /></td>";
//         drugName_ddcontents += "<br></br>";
//         drugName_ddcontents += "<label style= background-color: #00FFFF >Number of tablets per card</label>";
//         drugName_ddcontents += "<br/>"
//         drugName_ddcontents += "<td><input type=number name=tabletsPerCardValueDC id=tabletsPerCardValueDC /></td>";
//       }
//    else if(content == "bottles")
//    {
//         drugName_ddcontents += "<label style= background-color: #00FFFF >Number of bottles per cartoon</label>";
//         drugName_ddcontents += "<br/>"
//         drugName_ddcontents += "<td><input type=number name=numOfBottlesContentValueDC id=numOfBottlesContentValueDC /></td>";
//    }
     document.getElementById("cartoonspaceBC").innerHTML = drugName_ddcontents;
     document.getElementById("quantityspaceBC").innerHTML = "";
}

function getContentTypeDetails()
{
    var content   = $("#contentTypeDropDownBC option:selected").text();
    var type   = $("#typeDropDownBC option:selected").text();
    var contentType   = $("#contentDropDownBC option:selected").text();
    var drugName_ddcontents ="";
    
    if(type=="Cartoons" && content=="Tablets" && contentType=="Bottles")
    {
        drugName_ddcontents = "<label style= background-color: #00FFFF >Number of Cartoons</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfCartoonsContentValueDC id=numOfCartoonsContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<label style= background-color: #00FFFF >Number of Bottles per Cartoon</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfBottlesContentValueDC id=numOfBottlesContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<label style= background-color: #00FFFF >Number of Tablets per Bottle</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfTabletsContentValueDC id=numOfTabletsContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<input type=submit value='Calculate Quantity' onclick=calculateQuantityCTB()>";
        drugName_ddcontents += "<br></br>";
    }
    else if(type=="Cartoons" && content=="Tablets" && contentType=="Cards")
    {
        drugName_ddcontents = "<label style= background-color: #00FFFF >Number of Cartoons</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfCartoonsContentValueDC id=numOfCartoonsContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<label style= background-color: #00FFFF >Number of Cards per Cartoon</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfCardsContentValueDC id=numOfCardsContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<label style= background-color: #00FFFF >Number of Tablets per Card</label>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<td><input type=number name=numOfTabletsContentValueDC id=numOfTabletsContentValueDC /></td>";
        drugName_ddcontents += "<br/>"
        drugName_ddcontents += "<input type=submit value='Calculate Quantity' onclick=calculateQuantityCTC()>";
        drugName_ddcontents += "<br></br>";
    }
    document.getElementById("quantityspaceBC").innerHTML = drugName_ddcontents;
}

function calculateQuantityBT()
{
    //alert("Came in");
    var noOfBottles = parseInt($("#numOfBottlesContentValueDC").val());
    var noOfTabletsPerBottle = parseInt($("#numOfTabletsContentValueDC").val());
    var totalQty;
    if(noOfBottles > 0 && noOfTabletsPerBottle > 0)
    {
        totalQty = noOfBottles * noOfTabletsPerBottle;
        $("#quantityValueBC").val(totalQty);
        
    }
    else
    {
        alert("Please enter valid Quantities!!!");
    }
}

function calculateQuantityBL()
{
    //alert("Came in");
    var noOfBottles = parseInt($("#numOfBottlesContentValueDC").val());
    var totalQty;
    if(noOfBottles > 0)
    {
        totalQty = noOfBottles;
        $("#quantityValueBC").val(totalQty);
        
    }
    else
    {
        alert("Please enter valid Quantities!!!");
    }
}

function calculateQuantityCL()
{
    //alert("Came in");
    var noOfBottles = parseInt($("#numOfBottlesContentValueDC").val());
    var noOfCartoons = parseInt($("#numOfCartoonsContentValueDC").val());
    var totalQty;
    if(noOfBottles > 0 && noOfCartoons > 0)
    {
        totalQty = noOfBottles * noOfCartoons;
        $("#quantityValueBC").val(totalQty);
        
    }
    else
    {
        alert("Please enter valid Quantities!!!");
    }
}

function calculateQuantityCTB()
{
    //alert("Came in");
    var noOfBottles = parseInt($("#numOfBottlesContentValueDC").val());
    var noOfCartoons = parseInt($("#numOfCartoonsContentValueDC").val());
    var noOfTablets = parseInt($("#numOfTabletsContentValueDC").val());
    var totalQty;
    if(noOfBottles > 0 && noOfCartoons > 0 && noOfTablets > 0)
    {
        totalQty = noOfBottles * noOfCartoons * noOfTablets;
        $("#quantityValueBC").val(totalQty);
        
    }
    else
    {
        alert("Please enter valid Quantities!!!");
    }
}

function calculateQuantityCTC()
{
    //alert("Came in");
    var noOfCards = parseInt($("#numOfCardsContentValueDC").val());
    var noOfCartoons = parseInt($("#numOfCartoonsContentValueDC").val());
    var noOfTablets = parseInt($("#numOfTabletsContentValueDC").val());
    var totalQty;
    if(noOfCards > 0 && noOfCartoons > 0 && noOfTablets > 0)
    {
        totalQty = noOfCards * noOfCartoons * noOfTablets;
        $("#quantityValueBC").val(totalQty);
        
    }
    else
    {
        
        alert("Please enter valid Quantities!!!");
    }
}

function addDrugBatchBC(){

    //var drugId = $("#drugNameDropDownRC option:selected").attr('id');
    var drugName         = $("#drugNameDropDownBC option:selected").text();
    var batchNo          = document.getElementById("batchNoValueBC").value;
    var quantity         = document.getElementById("quantityValueBC").value;
    //var manufactureDate  = document.getElementById("manufactureDateValueBC").value;
    var manufactureDate  = $('#manufactureDateValueBC').val();
    //var expireDate       = document.getElementById("expireDateValueBC").value;
    var expireDate  = $('#expireDateValueBC').val();
    var batchError  = $("#batcherror").text();
    var qtyError  = $("#qtyerror").text();
    var mdateError  = $("#manerror").text();
    var edateError  = $("#experror").text();
    
    
    var exp = new Date(expireDate);
    var man = new Date(manufactureDate);
    
    var diff = new Date(exp-man);
    var days = diff/1000/60/60/24;
    //alert(days);

    if(batchNo.length==0 || quantity.length==0 || manufactureDate.length==0 || expireDate.length==0)        
    {
        alert("Please Fill all the Fields");
    }
    else if (batchError.length !=0 || qtyError.length !=0 || mdateError.length != 0 || edateError.length != 0)
    {
        alert("Some Fields are Invalid!!!");
    }
    else if(days <= 0)
    {
        alert("Expiry Date should be greater than Manufacture Date!!!");
    }
    else
    {
    $.ajax({
            url: 'http://localhost/eHealth_proj/index.php/Batch_controller/addBatch',
            type: 'POST',
            crossDomain: true,
            data: {"drugName":drugName ,"batchNo":batchNo,"quantity":quantity,
                   "manufactureDate":manufactureDate,"expireDate":expireDate},
            success: function(data) {
                 data = trimData(data);
                 alert(data);
                 $("#quantityValueBC").val("");
                 document.getElementById("cartoonspaceBC").innerHTML = "";
                 document.getElementById("quantityspaceBC").innerHTML = "";
                 document.getElementById("itemspaceBC").innerHTML ="";
            }
         });
    }
}



