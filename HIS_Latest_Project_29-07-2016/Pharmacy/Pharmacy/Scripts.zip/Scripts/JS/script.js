$(document).ready(function() {
    $("#manufactureDateValueBC").datepicker();
    $("#expireDateValueBC").datepicker();
});