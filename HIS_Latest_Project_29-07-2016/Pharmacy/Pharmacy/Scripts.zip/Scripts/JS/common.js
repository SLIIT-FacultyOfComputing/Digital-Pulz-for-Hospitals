function trimData(str){
        var n=str.split("<!");
        return n[0].trim();
    }